import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'ajax-loader',
    templateUrl: './loader.component.html',
    styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {    
    @Input() formData: any;
    @Input() selectedRow: any;
   
    @Output() modalSaveEvent = new EventEmitter();
    

    isLoaderShow: boolean = true;

    constructor() {
       
    }

    ngOnInit() {
        
    }
    showLoader() {
        this.isLoaderShow = false;
      //  setTimeout(this.hideLoader(), 5000);
    }

    hideLoader() {
        this.isLoaderShow = true;        
    }


}
